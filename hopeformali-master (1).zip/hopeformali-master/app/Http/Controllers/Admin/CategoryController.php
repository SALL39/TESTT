<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Session;
use Auth;
use Illuminate\Support\Facades\DB;
use App\model\Category;
use File;

class CategoryController extends Controller
{

    public function __construct()
    {
       $this->middleware('auth.admin');
    }

    public function index() {
        $categories = Category::orderBy('id','DESC')->get();
        return view('backend.category.index', compact('categories'));
    }

    public function create() {
        return view('backend.category.add');
    }

    public function store(Request $request) {
        $this->validate($request, [
            'categoryname' => 'required|max:50|unique:categories,categoryname',
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
            ],
            [],
            [
            'categoryname' => 'Category name',
            'image' => 'Image',
            ]
        );
        try{
            $uploadedimagename = imageupload($request);
            $category = new Category();
            $saveCategory = $category->createOrUpdateCategory($request, $uploadedimagename, 'create');
            if($saveCategory) {
                toastAlert('Category has been added successfully', 'success');
                return redirect('/admin/category');
            }else {
                toastAlert('Something went wrong, try again', 'error');
                return redirect()->back();
            }
        }catch(Exception $e){
            toastAlert('Something went wrong, try again', 'error');
            return redirect()->back();
        }   
    }


    public function edit($id) {
        $category = Category::find($id);
        return view('backend.category.edit', compact('category'));
    }

    public function update(Request $request) {
        $this->validate($request, [
            'categoryname' => 'required|max:50|unique:categories,categoryname,'.$request->categoryid,
            'image' => 'image|mimes:jpeg,png,jpg|max:2048',
            ],
            [],
            [
            'categoryname' => 'Category name',
            'image' => 'Image',
            ]
        );

        try{
            if(filesize($request->image) > 0) {
                $uploadedimagename = imageupload($request);
                File::delete(public_path().'/uploads/'.$request->oldcategoryimage);
            }else {
                $uploadedimagename = $request->oldcategoryimage;
            }
            
            $category = new Category();
            $saveCategory = $category->createOrUpdateCategory($request, $uploadedimagename, 'update');
            if($saveCategory) {
                toastAlert('Category has been updated successfully', 'success');
                return redirect('/admin/category');
            }else {
                toastAlert('Something went wrong, try again', 'error');
                return redirect()->back();
            }
        }catch(Exception $e){
            toastAlert('Something went wrong, try again', 'error');
            return redirect()->back();
        } 
    }

    public function delete($id) {
        $category = Category::find($id);
        File::delete(public_path().'/uploads/'.$category->categoryimage);
        $category->delete();
        toastAlert('Category deleted successfully', 'success');
        return redirect('/admin/category');
    }
}


