<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Region extends Model
{
    protected $table = 'regions';

    public function createOrUpdateRegion($data, $type) {
    	if ($type == 'create') {
    		$region = new Region();
    		$region->regionname = $data->regionname;
    		if ($region->save()) {
    			return true;
    		}else {
    			return false;
    		}
    	} elseif($type == 'update') {
    		$updateregion = Region::where(['id' => $data->regionid])->update([
    							'regionname' => $data->regionname,
    						  ]);
    		if ($updateregion) {
    			return true;
    		}else {
    			return false;
    		}
    	}
    }

    public static function getAllRegion() {
        return Region::orderBy('id', 'DESC')->get();
    }
}
