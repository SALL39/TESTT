@extends('backend.layout.master')

@section('title')
Region
@endsection
@section('content')

<div class="row">
          <div class="col-sm-12">
            <section class="panel">
              <header class="panel-heading">
                <a href="{{ url('/admin/region/create') }}" class="btn btn-info pull-right">Add Region</a>
                Region List
              </header>
              <table class="table table-condensed">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Region Name</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  @forelse ($regions as $value)
                  <tr>
                    <td>{{ $loop->index + 1}}</td>
                    <td>{{ $value->regionname }}</td>
                    <td>
                      <a href="{{ url('/admin/region/edit') }}/{{ $value->id }}" class="btn btn-success">Edit</a>
                      <a onclick="return confirm('Are you sure to delete?')" href="{{ url('/admin/region/delete') }}/{{ $value->id }}" class="btn btn-danger">Delete</a>
                    </td>
                  </tr>
                  @empty
                    <tr>
                      <td colspan="4" class="text-center">No Data Found</td>
                    </tr>
                  @endforelse
                </tbody>
              </table>
            </section>
          </div>
@endsection