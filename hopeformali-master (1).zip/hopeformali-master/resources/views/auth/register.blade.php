@extends('frontend.layout.master')

@section('content')

    <section id="registerlog" class="mt-5">
  <div class="container">
    <div class="content">
      <!-- Material form register -->
      <div class="card">
          <h5 style="text-align: center;" class="my-4">Vous avez déjà un compte? <a href="{{ url('/login') }}" class="text-info">se connecter</a></h5>
  
          <h5 class="card-header info-color white-text text-center py-4">
              <strong>S'inscrire</strong>
          </h5>

          <!--Card content-->
          <div class="card-body px-lg-5 pt-0">

              <!-- Form -->
              <form class="text-center" style="color: #757575;" method="POST" action="{{ url('/register') }}">
                 {{ csrf_field() }}
                  <div class="form-row">
                      <div class="col">
                          <!-- First name -->
                          <div class="md-form">
                              <input type="text" id="materialRegisterFormFirstName" class="form-control" name="firstname">
                              <label for="materialRegisterFormFirstName">Prénom</label>
                          </div>
                          @if($errors->has('firstname'))
                            <span class="error-block">{{ $errors->first('firstname') }}</span>
                          @endif
                      </div>
                      <div class="col">
                          <!-- Last name -->
                          <div class="md-form">
                              <input type="text" id="materialRegisterFormLastName" class="form-control" name="lastname">
                              <label for="materialRegisterFormLastName">Nom de famille</label>
                          </div>
                          @if($errors->has('lastname'))
                            <span class="error-block">{{ $errors->first('lastname') }}</span>
                          @endif
                      </div>
                  </div>

                  <!-- E-mail -->
                  <div class="md-form mt-0">
                      <input type="text" id="materialRegisterFormEmail" class="form-control" name="email">
                      <label for="materialRegisterFormEmail">Email</label>
                  </div>
                  @if($errors->has('email'))
                    <span class="error-block">{{ $errors->first('email') }}</span>
                  @endif

                  <!-- Password -->
                  <div class="md-form">
                      <input type="password" id="materialRegisterFormPassword" class="form-control" aria-describedby="materialRegisterFormPasswordHelpBlock" name="password">
                      <label for="materialRegisterFormPassword">Mot de passe</label>
                      <small id="materialRegisterFormPasswordHelpBlock" class="form-text text-muted mb-4">
                          Au moins 8 caractères et 1 chiffre
                      </small>
                  </div>
                  @if($errors->has('password'))
                    <span class="error-block">{{ $errors->first('password') }}</span>
                  @endif

                  <!-- Phone number -->
                  <div class="md-form">
                      <input type="text" id="materialRegisterFormPhone" class="form-control" aria-describedby="materialRegisterFormPhoneHelpBlock" name="phone">
                      <label for="materialRegisterFormPhone">Numéro de téléphone</label>
                      <small id="materialRegisterFormPhoneHelpBlock" class="form-text text-muted mb-4">
                          Facultatif - Pour une authentification en deux étapes
                      </small>
                      @if($errors->has('phone'))
                        <span class="error-block">{{ $errors->first('phone') }}</span>
                      @endif
                  </div>
                   

                  <!-- Newsletter -->
                  <div class="form-check">
                      <input type="checkbox" class="form-check-input" id="materialRegisterFormNewsletter" name="isnewsletter" value="1">
                      <label class="form-check-label" for="materialRegisterFormNewsletter">Abonnez-vous à notre newsletter</label>
                  </div>

                  <!-- Sign up button -->
                  <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0" type="submit">S'inscrire</button>

                  <!-- Social register -->
                  <p>ou inscrivez-vous avec:</p>

                  <a type="button" class="btn-floating btn-fb btn-sm">
                     <i class="fab fa-facebook-f" style="font-size:25px;margin-top: 5px;"></i>
                  </a>
    {{--               <a type="button" class="btn-floating btn-tw btn-sm">
                      <i class="fab fa-twitter"></i>
                  </a>
                  <a type="button" class="btn-floating btn-li btn-sm">
                      <i class="fab fa-linkedin"></i>
                  </a>
                  <a type="button" class="btn-floating btn-git btn-sm">
                      <i class="fab fa-github"></i>
                  </a> --}}

                  <hr>

                  <!-- Terms of service -->
                  <p>En cliquant
                      <em>S'inscrire</em>vous acceptez notre
                      <a href="" class="text-dark" target="_blank">conditions d'utilisation</a> and
                      <a href="" class="text-dark" target="_blank">conditions d'utilisation</a>. </p>

              </form>
              <!-- Form -->

          </div>

      </div>
      <!-- Material form register -->
    </div>
  </div>
  <script src="{{ asset('/backend/js/jquery.js') }}"></script>
  <script src="{{ asset('/backend/js/jquery-ui-1.10.4.min.js') }}"></script>
  <script src="{{ asset('/backend/js/jquery-1.8.3.min.js') }}"></script>
  @include('frontend.include.toaster')
</section>
@endsection