@extends('frontend.layout.master')

@section('content')
    <section id="registerlog" class="mt-5" style="width: 60%;margin: auto;">
    <div class="container">
      <div class="content">
        <!-- Material form register -->
        <div class="card">
            <h5 class="card-header info-color white-text text-center py-4">
                <strong>S'identifier</strong>
            </h5>

            <!--Card content-->
            <div class="card-body px-lg-5 pt-0">

                <!-- Form -->
                <form class="text-center" style="color: #757575;" method="POST" action="{{ url('/customlogin')}}">
                    {{ csrf_field() }}
                    <!-- E-mail -->
                    <div class="md-form mt-0">
                        <input type="text" id="materialRegisterFormEmail" class="form-control" autocomplete="off" name="email">
                        <label for="materialRegisterFormEmail">E-mail</label>
                    </div>
                    @if($errors->has('email'))
                      <span class="error-block">{{ $errors->first('email') }}</span>
                    @endif
                    @if(Session::has('incorrect-error'))
                      <span class="error-block">{{ Session::get('incorrect-error') }}</span>
                    @endif

                    <!-- Password -->
                    <div class="md-form">
                        <input type="password" id="materialRegisterFormPassword" class="form-control" aria-describedby="materialRegisterFormPasswordHelpBlock" autocomplete="off" name="password">
                        <label for="materialRegisterFormPassword">Password</label>
                        <small id="materialRegisterFormPasswordHelpBlock" class="form-text text-muted mb-4">
                            Au moins 8 caractères et 1 chiffre
                        </small>
                    </div>
                    @if($errors->has('password'))
                      <span class="error-block">{{ $errors->first('password') }}</span>
                    @endif

                    <!-- Sign up button -->
                    <button class="btn btn-outline-info btn-rounded btn-block my-4 waves-effect z-depth-0" type="submit">se connecter</button>

                    <!-- Social register -->
                    <p>ou inscrivez-vous avec:</p>

                    <a type="button" class="btn-floating btn-fb btn-sm">
                       <i class="fab fa-facebook-f" style="font-size:25px;margin-top: 5px;"></i>
                    </a>
                    {{-- <a type="button" class="btn-floating btn-tw btn-sm">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a type="button" class="btn-floating btn-li btn-sm">
                        <i class="fab fa-linkedin"></i>
                    </a>
                    <a type="button" class="btn-floating btn-git btn-sm">
                        <i class="fab fa-github"></i>
                    </a> --}}

                    <hr>

                    <!-- Terms of service -->
                    <p style="text-align: center;">En cliquant
                        <em>S'inscrire</em> vous acceptez notre
                        <a href="" target="_blank" class="text-info">conditions d'utilisation</a> and
                        <a href="" target="_blank" class="text-info">conditions d'utilisation</a>. </p>

                </form>
                <!-- Form -->

            </div>

        </div>
        <!-- Material form register -->
      </div>
    </div>
  </section>
  <script src="{{ asset('/backend/js/jquery.js') }}"></script>
  <script src="{{ asset('/backend/js/jquery-ui-1.10.4.min.js') }}"></script>
  <script src="{{ asset('/backend/js/jquery-1.8.3.min.js') }}"></script>
  @include('frontend.include.toaster')
@endsection