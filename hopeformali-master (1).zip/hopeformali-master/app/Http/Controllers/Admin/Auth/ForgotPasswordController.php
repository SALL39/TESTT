<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use App\model\Admin;
use App\Mail\ForgetPasswordMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use Session;
use Hash;
class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest.admin');
    }

    /**
     * Display the form to request a password reset link.
     *
     * @return \Illuminate\Http\Response
     */
    public function showLinkRequestForm()
    {
        return view('backend.forgetpassword.email');
    }

    public function ForgotPasswordEmail(Request $request) {
        $this->validate($request, [
            'email' => 'required|email'
        ]);

        $token = str_random(25);

        $admin = Admin::where(['email' => $request->email])->first();
        if($admin) {
            try {
                $admin->forget_password_token = $token;
                $admin->save();
                Mail::to($request->email)->send(new ForgetPasswordMail($admin, $token));
                Session::flash('forgetpass-success', 'Please check your email to reset your password');
                return redirect('/admin/forgetpassword');
            } catch(Exception $e) {
                Session::flash('forgetpass-error', 'Something went wrong, try again');
                return back();
            }
        }else {
            Session::flash('forgetpass-error', 'Email Not Found');
            return back();
        }
        
    }

    public function verifyToken($token) {
        if ($token) {
            $admin = Admin::where(['forget_password_token' => $token])->first();
            if ($admin) {
                return view('backend.forgetpassword.changepassword', compact('admin'));
            } else {
                Session::flash('forget-changepass-error', 'Token is invalid');
                return view('backend.forgetpassword.changepassword', compact('admin'));
            }
        } else {
            Session::flash('forget-changepass-error', 'Token is invalid');
            return view('backend.forgetpassword.changepassword', compact('admin'));
        }
    }

    public function changepassword(Request $request) {
        $this->validate($request, [
            'newpassword' => 'required|min:8|max:20|confirmed',
            'newpassword_confirmation' => 'required|min:8|max:20'
        ],
        [],
        [
        'newpassword' => 'New Password',
        'newpassword_confirmation' => 'Confirm password',

        ]
        );
        $admin = null;
        if ($request->passwordtoken) {
            $admin = Admin::where(['forget_password_token' => $request->passwordtoken])->first();
            if ($admin) {
                $newpassword = Hash::make($request->newpassword);
                Admin::where('id', $admin->id)
                ->update([
                    'password'  => $newpassword,
                    'forget_password_token' => null
                    ]);
                Session::flash('forget-changepass-success', 'Password has been changed successfully');
                return view('backend.forgetpassword.changepassword', compact('admin'));
            } else {
                Session::flash('forget-changepass-error', 'Something went wrong, try again');
                return view('backend.forgetpassword.changepassword', compact('admin'));
            }
        } else {
            Session::flash('forget-changepass-error', 'Something went wrong, try again');
            return view('backend.forgetpassword.changepassword', compact('admin'));
        }
    }
}
