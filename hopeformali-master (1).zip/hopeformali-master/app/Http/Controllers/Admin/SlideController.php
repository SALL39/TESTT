<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Session;
use Auth;
use Illuminate\Support\Facades\DB;
use App\model\Slide;
use File;
class SlideController extends Controller
{

    public function __construct()
    {
       $this->middleware('auth.admin');
    }

    public function index() {
        $slides = Slide::orderBy('id','DESC')->get();
        return view('backend.slide.index', compact('slides'));
    }

    public function create() {
        return view('backend.slide.add');
    }

    public function store(Request $request) {
        $this->validate($request, [
            'image' => 'required|image|mimes:jpeg,png,jpg|max:2048',
            ],
            [],
            [
            'image' => 'Image',
            ]
        );
        try{
            $uploadedimagename = imageupload($request);
            $slide = new Slide();
            $saveSlide = $slide->createOrUpdateSlide($request, $uploadedimagename, 'create');
            if($saveSlide) {
                toastAlert('Slide has been added successfully', 'success');
                return redirect('/admin/slide');
            }else {
                toastAlert('Something went wrong, try again', 'error');
                return redirect()->back();
            }
        }catch(Exception $e){
            toastAlert('Something went wrong, try again', 'error');
            return redirect()->back();
        }   
    }


    public function edit($id) {
        $slide = Slide::find($id);
        return view('backend.slide.edit', compact('slide'));
    }

    public function update(Request $request) {
        $this->validate($request, [
            'image' => 'image|mimes:jpeg,png,jpg|max:2048',
            ],
            [],
            [
            'image' => 'Image',
            ]
        );

        try{
            if(filesize($request->image) > 0) {
                $uploadedimagename = imageupload($request);
                File::delete(public_path().'/uploads/'.$request->oldslideimage);
            }else {
                $uploadedimagename = $request->oldslideimage;
            }
            
            $slide = new Slide();
            $saveSlide= $slide->createOrUpdateSlide($request, $uploadedimagename, 'update');
            if($saveSlide) {
                toastAlert('Slide has been updated successfully', 'success');
                return redirect('/admin/slide');
            }else {
                toastAlert('Something went wrong, try again', 'error');
                return redirect()->back();
            }
        }catch(Exception $e){
            toastAlert('Something went wrong, try again', 'error');
            return redirect()->back();
        } 
    }

    public function delete($id) {
        $slide = Slide::find($id);
        File::delete(public_path().'/uploads/'.$slide->slideimage);
        $slide->delete();
        toastAlert('Slide deleted successfully', 'success');
        return redirect('/admin/slide');
    }
}


