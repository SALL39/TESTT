@extends('backend.layout.master')


@section('title')
	Add Slide
@endsection

@section('content')

<div class="row ml-auto mr-auto">
  <div class="col-md-6">
	<section class="panel">
              <header class="panel-heading">
                Add Slide

              </header>
              <div class="panel-body">
                <form class="form-horizontal" role="form" method="POST" action="{{ url('/admin/slide/store') }}" enctype="multipart/form-data">
                  {{ csrf_field() }}
                
                  <div class="form-group">
                    <label for="inputPassword1" class="col-lg-3 control-label">Image</label>
                    <div class="col-lg-9">
                      <input type="file" class="form-control" name="image">
                      @if ($errors->has('image'))
                          <span class="help-block small" style="color:red"> {{ $errors->first('image') }}</span>
                      @endif
                    </div>
                  </div>
                  
                    <div class="col-lg-offset-2 col-lg-10">
                      <button type="submit" class="btn btn-danger pull-right">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            </section>
           </div> 
</div>      
    
@endsection
