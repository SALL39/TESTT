<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\model\Region;
class RegionController extends Controller
{

    public function __construct()
    {
       $this->middleware('auth.admin');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $regions = Region::orderBy('id', 'DESC')->get();
        return view('backend.region.index', compact('regions'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create() {
        return view('backend.region.add');
    }

    public function store(Request $request) {
        $this->validate($request, [
            'regionname' => 'required|max:50|unique:regions,regionname',
            ],
            [],
            [
            'regionname' => 'Region name'
            ]
        );
        try{
            $region = new Region();
            $saveRegion = $region->createOrUpdateRegion($request, 'create');
            if($saveRegion) {
                toastAlert('Region has been added successfully', 'success');
                return redirect('/admin/region');
            }else {
                toastAlert('Something went wrong, try again', 'error');
                return redirect()->back();
            }
        }catch(Exception $e){
            toastAlert('Something went wrong, try again', 'error');
            return redirect()->back();
        }   
    }


    public function edit($id) {
        $region = Region::find($id);
        return view('backend.region.edit', compact('region'));
    }

    public function update(Request $request) {
        $this->validate($request, [
            'regionname' => 'required|max:50|unique:regions,regionname,'.$request->regionid,
            ],
            [],
            [
            'regionname' => 'Region name',
            ]
        );

        try{
            $region = new Region();
            $saveregion = $region->createOrUpdateRegion($request, 'update');
            if($saveregion) {
                toastAlert('Region has been updated successfully', 'success');
                return redirect('/admin/region');
            }else {
                toastAlert('Something went wrong, try again', 'error');
                return redirect()->back();
            }
        }catch(Exception $e){
            toastAlert('Something went wrong, try again', 'error');
            return redirect()->back();
        } 
    }

    public function delete($id) {
        Region::find($id)->delete();
        toastAlert('Region deleted successfully', 'success');
        return redirect('/admin/region');
    }
}
