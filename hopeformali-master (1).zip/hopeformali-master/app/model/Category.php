<?php

namespace App\model;
use Illuminate\Database\Eloquent\Model;
class Category extends Model
{
    protected $table = 'categories';


    public function createOrUpdateCategory($data, $imagename, $type) {
    	if ($type == 'create') {
    		$category = new Category();
    		$category->categoryname = $data->categoryname;
    		$category->categoryimage = $imagename;
    		if ($category->save()) {
    			return true;
    		}else {
    			return false;
    		}
    	} elseif($type == 'update') {
    		$updatecategory = Category::where(['id' => $data->categoryid])->update([
    							'categoryname' => $data->categoryname,
    							'categoryimage'	=> $imagename
    						  ]);
    		if ($updatecategory) {
    			return true;
    		}else {
    			return false;
    		}
    	}
    }

    public static function getAllCategory() {
        return Category::orderBy('id', 'DESC')->get();
    }
}