<?php
if (! function_exists('imageupload')) {
    function imageupload($file)
    {	
    	if (filesize($file->image) > 0) {
    		$imageExtension = $file->image->getClientOriginalExtension();
	        $card = str_random(10);
	        $imageName = 'img'.time().$card.'.'.$imageExtension;
	        $uploadedFile = $file->image->move(public_path('uploads'),$imageName);
	        return $imageName;
    	} else {
    		return null;
    	}
        
    }
}

if (! function_exists('toastAlert')) {
    function toastAlert($msg, $type)
    {
    	if($msg) {
    		Toastr::clear();
    		if($type == 'success') {
    			Toastr::success($msg, 'Success', ["positionClass" => "toast-top-right"]);
    		}elseif($type == 'error') {
    			Toastr::error($msg, 'Error', ["positionClass" => "toast-top-right"]);
    		}
    	}
        
    }
}


?>