@extends('backend.layout.master')

@section('title')
Category
@endsection
@section('content')

<div class="row">
          <div class="col-sm-12">
            <section class="panel">
              <header class="panel-heading">
                <a href="{{ url('/admin/category/create') }}" class="btn btn-info pull-right">Add Category</a>
                Category List
              </header>
              <table class="table table-condensed">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Category Name</th>
                    <th>Category Image</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  @forelse ($categories as $value)
                  <tr>
                    <td>{{ $loop->index + 1}}</td>
                    <td>{{ $value->categoryname }}</td>
                    <td><img src="{{ URL::to('/uploads') }}/{{ $value->categoryimage }}" width="100" height="100"></td>
                    <td>
                      <a href="{{ url('/admin/category/edit') }}/{{ $value->id }}" class="btn btn-success">Edit</a>
                      <a onclick="return confirm('Are you sure to delete?')" href="{{ url('/admin/category/delete') }}/{{ $value->id }}" class="btn btn-danger">Delete</a>
                    </td>
                  </tr>
                  @empty
                    <tr>
                      <td colspan="4" class="text-center">No Data Found</td>
                    </tr>
                  @endforelse
                </tbody>
              </table>
            </section>
          </div>
@endsection