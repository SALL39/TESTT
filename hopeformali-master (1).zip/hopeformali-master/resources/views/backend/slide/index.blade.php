@extends('backend.layout.master')

@section('title')
Slide
@endsection
@section('content')

<div class="row">
          <div class="col-sm-12">
            <section class="panel">
              <header class="panel-heading">
                <a href="{{ url('/admin/slide/create') }}" class="btn btn-info pull-right">Add Slide</a>
                Slide List
              </header>
              <table class="table table-condensed">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Slide Image</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  @forelse ($slides as $value)
                  <tr>
                    <td>{{ $loop->index + 1}}</td>
                    <td><img src="{{ URL::to('/uploads') }}/{{ $value->slideimage }}" width="100" height="100"></td>
                    <td>
                      <a href="{{ url('/admin/slide/edit') }}/{{ $value->id }}" class="btn btn-success">Edit</a>
                      <a onclick="return confirm('Are you sure to delete?')" href="{{ url('/admin/slide/delete') }}/{{ $value->id }}" class="btn btn-danger">Delete</a>
                    </td>
                  </tr>
                  @empty
                    <tr>
                      <td colspan="4" class="text-center">No Data Found</td>
                    </tr>
                  @endforelse
                </tbody>
              </table>
            </section>
          </div>
@endsection