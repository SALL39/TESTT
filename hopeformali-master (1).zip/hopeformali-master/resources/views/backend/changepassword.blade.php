@extends('backend.layout.master')


@section('title')
	Change password
@endsection

@section('content')

<div class="row ml-auto mr-auto">
  <div class="col-md-6">
	<section class="panel">
              <header class="panel-heading">
                Chnage password

              </header>
              @if(Session::has('change-success'))
                          <div class="alert alert-success alert-sm"> {{ Session::get('change-success') }}</div>
                        @endif
              <div class="panel-body">
                <form class="form-horizontal" role="form" method="POST" action="{{ url('/admin/changepassword') }}">
                  {{ csrf_field() }}
                 <div class="form-group">
                    <label for="inputPassword1" class="col-lg-3 control-label">Old Password</label>
                    <div class="col-lg-9">
                      <input type="password" class="form-control" id="inputPassword1" placeholder="Old Password" name="oldpassword">
                       @if ($errors->has('oldpassword'))
                          <span class="help-block small" style="color:red"> {{ $errors->first('oldpassword') }}</span>
                      @endif
                        @if(Session::has('mismatch'))
                          <span class="help-block small" style="color:red"> {{ Session::get('mismatch') }}</span>
                        @endif
                    </div>
                  </div>
                 
                
                  <div class="form-group">
                    <label for="inputPassword1" class="col-lg-3 control-label">New Password</label>
                    <div class="col-lg-9">
                      <input type="password" class="form-control" id="inputPassword1" placeholder="New Password" name="newpassword">
                      @if ($errors->has('newpassword'))
                          <span class="help-block small" style="color:red"> {{ $errors->first('newpassword') }}</span>
                      @endif
                    </div>
                  </div>
                  
                  <div class="form-group">
                    <label for="inputPassword1" class="col-lg-3 control-label">Confirm New Password</label>
                    <div class="col-lg-9">
                      <input type="password" class="form-control" id="inputPassword1" placeholder="Confirm New Password" name="newpassword_confirmation">
                      @if ($errors->has('newpassword_confirmation'))
                          <span class="help-block small" style="color:red"> {{ $errors->first('newpassword_confirmation') }}</span>
                      @endif
                    </div>
                  </div>
                  
                    <div class="col-lg-offset-2 col-lg-10">
                      <button type="submit" class="btn btn-danger pull-right">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            </section>
           </div> 
</div>      
    
@endsection
