<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Socialite;
use Exception;
use Auth;
use Illuminate\Http\Request;
use App\Product;
class SocialAuthController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function redirect($provider)
    {
        return Socialite::driver($provider)->redirect();
    }

    /**
     * Get the user info from provider and check if user exist for specific provider
     * then log them in otherwise
     * create a new user then log them in 
     * Once user is logged in then redirect to authenticated home page
     *
     * @return Response
     */
    public function callback($provider)
    {
       
        try {
            $user = Socialite::driver($provider)->user();
            
            $name = $user->getName();

            $name = explode(' ', $name);
            $firstname = $name[0];
            $lastname = array_key_exists(1, $name) ? $name[1]:null;
            $input['firstname'] = $firstname;
            $input['lastname'] = $lastname;
            if($user->getEmail() != null){
                $input['email'] = $user->getEmail();
            }
            $input['provider'] = $provider;
            $input['provider_id'] = $user->getId();

            $authUser = $this->findOrCreate($input);
            if($authUser){
                Auth::loginUsingId($authUser->id);
            }
            return redirect('/');


        } catch (Exception $e) {
            return redirect('auth/'.$provider);

        }
    }
    public function findOrCreate($input){
        
        if(array_key_exists("email",$input)){
            $checkExist = User::where('email',$input['email'])->first();
            if($checkExist){
                return $checkExist;
            }
        }
        
        $checkExist = User::where('provider',$input['provider'])->where(['provider_id' => $input['provider_id']])->first();
        if($checkExist){
            return $checkExist;
        }
        return User::create($input);

    }
}