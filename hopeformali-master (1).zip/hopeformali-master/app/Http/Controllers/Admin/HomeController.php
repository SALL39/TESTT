<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Session;
use Auth;
use Illuminate\Support\Facades\DB;
use App\model\Admin;
use Hash;
class HomeController extends Controller
{

    public function __construct()
    {
       $this->middleware('auth.admin');
    }

    public function index() {
        return view('backend.home');
    }

    public function changePasswordForm(){
    	return view('backend.changepassword');
    }

    public function changePassword(Request $request) {
    	$this->validate($request, [
            'oldpassword' => 'required',
            'newpassword' => 'required|min:8|max:20|confirmed',
            'newpassword_confirmation' => 'required|min:8|max:20'
        ],
        [],
        [

        'oldpassword' => 'Old Password',
        'newpassword' => 'New Password',
        'newpassword_confirmation' => 'Confirm password',

        ]
        );

         $id = Auth::guard('admins')->id();
         $password = Admin::find($id)->password;
         $newpassword = Hash::make($request['newpassword']);
        if(Hash::check($request['oldpassword'], $password))
        { 
            $admin = new Admin();
            $admin->where('id', $id)
            ->update([
                'password'  => $newpassword,
                ]);
            Session::flash('change-success', 'Password has been changed successfully');
            return redirect('/admin/changepassword');
        }else{
            Session::flash('mismatch', 'Old password does not macthed');
            return redirect('/admin/changepassword');
        }
    }

}


