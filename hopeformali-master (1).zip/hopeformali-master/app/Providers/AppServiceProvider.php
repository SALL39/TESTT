<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\model\Category;
use App\model\Region;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('frontend.layout.master', function($view)
        {
            $view->with('categories', Category::getAllCategory());
        });

        view()->composer('frontend.layout.master', function($view)
        {
            $view->with('regions', Region::getAllRegion());
        });

        
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
