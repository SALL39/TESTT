<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthSocialAuth extends Controller
{
    //
}
