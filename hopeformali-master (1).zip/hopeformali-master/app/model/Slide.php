<?php

namespace App\model;
use Illuminate\Database\Eloquent\Model;
class Slide extends Model
{
    protected $table = 'slides';
     public function createOrUpdateSlide($data, $imagename, $type) {
        if ($type == 'create') {
            $slide = new Slide();
            $slide->slideimage = $imagename;
            if ($slide->save()) {
                return true;
            }else {
                return false;
            }
        } elseif($type == 'update') {
            $updateslide = Slide::where(['id' => $data->slideid])->update([
                                'slideimage' => $imagename
                              ]);
            if ($updateslide) {
                return true;
            }else {
                return false;
            }
        }
    }
}