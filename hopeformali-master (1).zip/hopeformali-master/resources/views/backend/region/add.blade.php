@extends('backend.layout.master')


@section('title')
	Add Region
@endsection

@section('content')

<div class="row ml-auto mr-auto">
  <div class="col-md-6">
	<section class="panel">
              <header class="panel-heading">
                Add Region

              </header>
              <div class="panel-body">
                <form class="form-horizontal" role="form" method="POST" action="{{ url('/admin/region/store') }}" enctype="multipart/form-data">
                  {{ csrf_field() }}
                 <div class="form-group">
                    <label for="inputPassword1" class="col-lg-3 control-label">Region name</label>
                    <div class="col-lg-9">
                      <input type="text" class="form-control" id="inputPassword1" placeholder="Region name" name="regionname">
                       @if ($errors->has('regionname'))
                          <span class="help-block small" style="color:red"> {{ $errors->first('regionname') }}</span>
                      @endif
                    </div>
                  </div>
                 
                    <div class="col-lg-offset-2 col-lg-10">
                      <button type="submit" class="btn btn-danger pull-right">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            </section>
           </div> 
</div>      
    
@endsection
